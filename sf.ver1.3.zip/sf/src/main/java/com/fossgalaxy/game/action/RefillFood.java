package com.fossgalaxy.game.action;

public class RefillFood {
}
