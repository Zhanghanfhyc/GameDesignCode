package com.fossgalaxy.game.order;

public class RefillFoodOrder {
}
