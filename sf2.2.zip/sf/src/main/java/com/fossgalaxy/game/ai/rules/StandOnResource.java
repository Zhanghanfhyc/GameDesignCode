package com.fossgalaxy.game.ai.rules;

import com.fossgalaxy.games.tbs.GameState;
import com.fossgalaxy.games.tbs.ai.rules.AgentUtils;
import com.fossgalaxy.games.tbs.ai.rules.PerEntityRule;
import com.fossgalaxy.games.tbs.entity.Entity;
import com.fossgalaxy.games.tbs.entity.Resource;
import com.fossgalaxy.games.tbs.order.MineOrder;
import com.fossgalaxy.games.tbs.order.Order;
import com.fossgalaxy.games.tbs.parameters.ResourceType;
import com.fossgalaxy.object.annotations.ObjectDef;

import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

/**
 * Created by Lhfver on 21/05/2018.
 */
public class StandOnResource extends PerEntityRule{

    private final ResourceType targetResource;

    @ObjectDef("StandOnResource")
    public StandOnResource(ResourceType targetResource) {
        this.targetResource = Objects.requireNonNull(targetResource);
    }

    @Override
    public boolean isForEntity(GameState gameState, Entity entity) {
        return true;
    }

    @Override
    public Order generateOrder(GameState gameState, Entity entity) {
        List<Resource> resources = gameState.getResources().stream().filter(x -> x.getType().equals(targetResource)).collect(Collectors.toList());

        if(resources.isEmpty()) return null;

        Resource resourceOn = gameState.getResourceAt(entity.getPos());
        if(resourceOn != null && resourceOn.getType().equals(targetResource)){
            return new MineOrder(targetResource, 1);
        }

        Resource closest = null;
        double closestDistance = Double.MAX_VALUE;
        for(Resource resource : resources){
            Entity at = gameState.getEntityAt(resource.getLocation());
            if(at != null) continue;
            double distance = gameState.getDistance(entity.getPos(), resource.getLocation());
            if(distance < closestDistance){
                closest = resource;
                closestDistance = distance;
            }
        }

        if(closest == null) return null;
        return AgentUtils.pathTowards(gameState, entity, closest.getLocation());
    }
}
