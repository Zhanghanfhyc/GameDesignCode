package com.fossgalaxy.game.action;

import com.fossgalaxy.game.order.GameBuildOrder;
import com.fossgalaxy.games.tbs.GameState;
import com.fossgalaxy.games.tbs.actions.BuildAction;
import com.fossgalaxy.games.tbs.order.BuildOrder;
import com.fossgalaxy.games.tbs.order.Order;
import com.fossgalaxy.games.tbs.parameters.EntityType;
import com.fossgalaxy.object.annotations.ObjectDef;
import org.codetome.hexameter.core.api.CubeCoordinate;

public class gameBuild extends BuildAction {
    //@ObjectDef("Build")
    public gameBuild(EntityType type) {
        super(type);

    }

    @Override
    public Order generateOrder(CubeCoordinate co, GameState s) {
        return new GameBuildOrder(this.type, co);
    }
}
