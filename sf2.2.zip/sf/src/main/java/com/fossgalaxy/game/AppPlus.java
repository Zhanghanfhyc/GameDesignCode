package com.fossgalaxy.game;

import com.fossgalaxy.games.tbs.App;

/**
 * Created by cy17261 on 22/05/2018.
 */
public class AppPlus extends App{
    public AppPlus() {
    }
}
