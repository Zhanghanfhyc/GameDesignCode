package com.fossgalaxy.game.order;

import com.fossgalaxy.games.tbs.GameState;
import com.fossgalaxy.games.tbs.actions.BuildAction;
import com.fossgalaxy.games.tbs.order.BuildOrder;
import com.fossgalaxy.games.tbs.order.Order;
import com.fossgalaxy.games.tbs.parameters.EntityType;
import com.fossgalaxy.games.tbs.parameters.TerrainType;
import com.fossgalaxy.games.tbs.ui.GameAction;
import org.codetome.hexameter.core.api.CubeCoordinate;

import javax.swing.text.html.parser.Entity;
import java.util.*;

public class GameBuildOrder implements Order {
    public  EntityType type;
    private CubeCoordinate cube;
    private Random random;

    public GameBuildOrder(EntityType type, CubeCoordinate cube) {
        this.type = type;
        this.cube = cube;
        this.random = new Random();


    }

    public void doOrder(com.fossgalaxy.games.tbs.entity.Entity host, GameState state) {
        if (this.substituteType(host)) {
            if (this.isNextToMe(host, state)) {
                if (this.isTerrainPassableForBuildTypeOrShouldTheyGoHome(state)) {
                    if (!this.isSpaceEmpty(state)) {
                        if (this.payIfPossible(host, state)) {
                            this.build(host, state);
                        }
                    }
                }
            }
        }
    }

    protected boolean substituteType(com.fossgalaxy.games.tbs.entity.Entity host) {
        List<GameAction> actions = host.getType().getAvailableActions();
        List<EntityType> viableTypes = new ArrayList();
        Iterator var4 = actions.iterator();

        while(var4.hasNext()) {
            GameAction action = (GameAction)var4.next();
            if (action instanceof BuildAction) {
                BuildAction build = (BuildAction)action;
                EntityType buildType = build.getProductionType();
                if (buildType.equals(this.type)) {
                    return true;
                }

                if (buildType.isInstance(this.type)) {
                    viableTypes.add(buildType);
                }
            }
        }

        if (viableTypes.isEmpty()) {
            return false;
        } else {
            this.type = (EntityType)viableTypes.get(this.random.nextInt(viableTypes.size()));
            return true;
        }
    }

    protected boolean isNextToMe(com.fossgalaxy.games.tbs.entity.Entity host, GameState state) {
        return state.getDistance(host.getPos(), this.cube) == 1;
    }

    protected boolean isTerrainPassableForBuildTypeOrShouldTheyGoHome(GameState state) {
        TerrainType tt = state.getTerrainAt(this.cube);
        return tt == null ? false : state.getTerrainAt(this.cube).isPassible(this.type);
    }

    protected void build(com.fossgalaxy.games.tbs.entity.Entity host, GameState state) {
        com.fossgalaxy.games.tbs.entity.Entity e = new com.fossgalaxy.games.tbs.entity.Entity(this.type, this.cube, host.getOwner());
        state.addEntity(e);
    }

    protected boolean payIfPossible(com.fossgalaxy.games.tbs.entity.Entity host, GameState state) {
        Map<String, Integer> cost = this.type.getCosts();
        Iterator var4 = cost.entrySet().iterator();

        Map.Entry costEntry;
        String t;
        int costVal;
        while(var4.hasNext()) {
            costEntry = (Map.Entry)var4.next();
            t = (String)costEntry.getKey();
            costVal = ((Integer)costEntry.getValue()).intValue();
            int currStore = state.getResource(host.getOwner(), t);
            if (currStore < costVal) {
                return false;
            }
        }

        var4 = cost.entrySet().iterator();

        while(var4.hasNext()) {
            costEntry = (Map.Entry)var4.next();
            t = (String)costEntry.getKey();
            costVal = ((Integer)costEntry.getValue()).intValue();
            state.addResource(host.getOwner(), t, -costVal);
        }

        return true;
    }

    protected boolean isSpaceEmpty(GameState state) {
        com.fossgalaxy.games.tbs.entity.Entity entity = state.getEntityAt(this.cube);
        return entity != null;
    }

    public String toString() {
        return String.format("build %s at (%d, %d)", this.type, this.cube.getGridX(), this.cube.getGridZ());
    }
}
