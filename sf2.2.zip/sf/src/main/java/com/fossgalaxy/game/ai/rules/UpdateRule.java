package com.fossgalaxy.game.ai.rules;

import com.fossgalaxy.games.tbs.actions.AbstractAction;
import com.fossgalaxy.games.tbs.ai.rules.FirstLegalRule;
import com.fossgalaxy.object.annotations.ObjectDef;

/**
 * Created by cy17261 on 21/05/2018.
 */
public class UpdateRule extends FirstLegalRule {

    @ObjectDef("UpgradeSelf")
    public UpdateRule() {
        super(AbstractAction.CAT_UPGRADE);
    }
}
