package com.fossgalaxy.game.ai.rules;

/**
 * Created by cy17261 on 21/05/2018.
 */
public class MineRule {

}
