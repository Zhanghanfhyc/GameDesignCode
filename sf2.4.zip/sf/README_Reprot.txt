Strategy style game

//initial 
Two players start with a main building and a farmer.
//units and their functions
Famers could build(barracks��ranges and stables), mine(golds and woods),and attack.
Barracks could generate soliders, which could do melee attack.
Ranges could generate bowmans,which could do range attack.
Stables could generate cavalry, which could do melee attack.
//victory condition
The victory condition is destory enemy's main building.


//game mechanic
1. Famers, soliders, bowmans, and cavalry have "food" property, which will be cost if the unit do move action.
2. Units will die when run out of its food, which is similar with HP
3. Units could restore food when near a allies' buildings.
4. Units could be upgrade use sourse
5. Famers build buildings need cost resource
6. Building generate units need cost resource


Parameters:
*Attack range, attack damage, defence armor, health, move speed
	Effect: balance restrain relationship
*Cost for generate and build
	Effect: balance resource useage 
*Mine speed
	Effect: balance game play speed
*Upgrade and its cost
	Effect: make the game interesting, motivate player enthusiasm 


